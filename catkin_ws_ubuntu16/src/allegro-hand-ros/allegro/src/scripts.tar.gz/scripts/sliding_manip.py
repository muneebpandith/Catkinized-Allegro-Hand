#!/usr/bin/env python

from urdf_parser_py.urdf import URDF
from pykdl_utils.kdl_parser import kdl_tree_from_urdf_model
from pykdl_utils.kdl_kinematics import KDLKinematics
from urdf_parser_py.urdf import Robot
import numpy as np
import rospy
from sensor_msgs.msg import JointState
from rospy_tutorials.msg import Floats
import time
import PyKDL as kdl
from allegro_work_class import my_allegro

time.sleep(1)
obj = my_allegro()
#obj.jacob_control_main()
#obj.set_point()	
desired_joints_move_left = np.array([-0.06591540252368783, 0.4970301769948841, 1.5074363426048536, 0.9269305335879235, -0.03619493704043024, -0.11524669422184043, 0.8246091996301753, 0.8075973057698066, 0.5085805019627585, 0.8028981528624055, 1.2178820212278554, 0.7433312663379661, 0.955560193262842, 0.44093597913205274, 0.2739404989461801, 0.7466180454156772])
desired_joints_move_left = np.array([-0.010942074357428676, 0.8245303216075556, 1.2818913264817375, 0.9791039295244994, 0.10171340463565817, 0.5375934129730376, 1.2766683441259419, 0.7899868172985625, 0.2545089751242168, 0.9286678492788186, 1.1000056588050138, 0.798956335109, 1.3065067454003056, 0.3063566065516141, 0.19382882417690628, 1.2927834481495548])

desired_joints_move_down = np.array([0.4560855512931522, 0.013516596265732806, 0.6541364244349401, 0.3984426139772528, 0.3581369899354219, 0.5640755668665262, 1.496873904625197, 0.7824848718742048, -0.16280217943327524, 0.12915665930069326, 0.3480924773905169, 0.26914962820765803, 1.552680947869152, 0.17989913195612117, 0.2850479940810432, 1.4396384498744939])
desired_joints_move_down = np.array([-0.010942074357428676, 0.8245303216075556, 1.2818913264817375, 0.9791039295244994, 0.10171340463565817, 0.5375934129730376, 1.2766683441259419, 0.7899868172985625, 0.2545089751242168, 0.9286678492788186, 1.1000056588050138, 0.798956335109, 1.3065067454003056, 0.3063566065516141, 0.19382882417690628, 1.2927834481495548])
desired_joints_move_net = 0*desired_joints_move_left
for i in range(4):

	desired_joints_move_net[i] = desired_joints_move_left[i]
	desired_joints_move_net[i+4] = desired_joints_move_down[i+4]
	desired_joints_move_net[i+8] = desired_joints_move_left[i+8]
	desired_joints_move_net[i+12] = desired_joints_move_down[i+12]

obj.reachgoalpose(desired_joints_move_net)


raw_input("Press Enter to continue...")
# flag: 1 if camera and object is there 0 for dummy work
obj.calib_pose(0)
raw_input("Press Enter to continue...")
# desired motion of the object #routine: fingertips to move vis-a-vis fixed
deld1 = np.array([0.00,0.0,-0.002])
deld2 = np.array([0.00,0.0,-0.002])
raw_input("Press Enter")
out_databef = np.zeros(16)
for i in range(16):
	out_databef[i] = desired_joints_move_net[i]

def putitl(out_databef):
	print("OUThurray",out_databef)

	routine = [1,0,1,0]
	out_data=obj.release_fing(routine,out_databef)
	time.sleep(1)
	
	deld = np.array([0.00,-0.008,0.0])
	out_datac=obj.kin_t_sl(deld,routine,out_data)
	time.sleep(1)
	out_databef=obj.regrasp(routine,out_datac,out_databef)	

	return out_databef

def putitu(out_databef):

	routine = [0,1,0,1]
	out_data=obj.release_fing([1,1,1,1],out_databef)
	time.sleep(1)
	deld = np.array([0.00,0.0,-0.003])
	out_datac=obj.kin_t_sl(deld,routine,out_data)

	time.sleep(1)

	out_databef=obj.regrasp(routine,out_datac,out_databef)	
	return out_databef	
##Start 16
for i in range(1):

	out_databef=putitl(out_databef)
## End 1
	time.sleep(1)

	out_databef=putitu(out_databef)
	time.sleep(1)
	out_databef=putitl(out_databef)
## End 1
	time.sleep(1)
	out_databef=putitu(out_databef)
	time.sleep(1)
	out_databef=putitl(out_databef)
## End 1
	time.sleep(1)
	out_databef=putitu(out_databef)
	time.sleep(1)
	out_databef=putitl(out_databef)
## Start 2


## End 2
#raw_input("Press Enter")
#out_data=obj.release_fing([0,1,0,1],desired_joints_move_net)
#print(out_data)
#time.sleep(1)
#deld = np.array([0.00,0.0,-0.01])
#obj.kin_t_sl(deld,[0,1,0,1],out_data)

#time.sleep(1)
#obj.reachgoalpose(desired_joints_move_net)
#time.sleep(1)
#deld = np.array([0.00,0.0,0.002])
#obj.kin_t(deld,[0,1,0,1])

